1. Copy the web folder in xampp htdocs folder. Import the mysql data file given into the phpmyadmin of your localhost. Run the index.html file.

2. The datasets folder contains the datasets of water requirements of different crops in different condiitons in order to automate the process of irrigation by importing the dataset into iot devices. 