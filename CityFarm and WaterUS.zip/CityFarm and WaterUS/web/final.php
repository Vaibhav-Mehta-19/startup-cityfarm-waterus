
<?php include 'header.php';
	?>

<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- contact -->
<section class="contact py-5">
	<div class="container py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center"> Your order haas been placed successfully.!! Thanks for shopping with us..</h3>
		
		
		
	</div>
</section>
<!-- //contact -->
<?php 
include('connect.php');

if(isset($_POST['contact'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$message=$_REQUEST['message'];
	


$sql="insert into contact(`name`,`email`,`phone`,`message`) values('$name','$email','$phone','$message')";

$res=mysqli_query($con,$sql);

if($res>=1){




echo "<script>alert('query submitted!! we will get back soon');</script>";


}
else{

echo "<script>alert('oops! Error Occur. Please try again later');</script>";

}

}
?>

<?php include 'footer.php';
	?>
