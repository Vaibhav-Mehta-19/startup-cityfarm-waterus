
              <?php include 'header.php';
  ?>
<!-- banner -->
<div class="inner-banner" id="home">
  <div class="container">
  </div>
</div>
<!-- //banner -->

<?php

 if(isset($_SESSION['fuser']))
 {
 include('connect.php');
$fuser=$_SESSION['fuser'];

$sql="select * from add_product where `user`='$fuser'  ";

 $res=mysqli_query($con,$sql);
 ?>

  <div class="panel panel-primary">
 <div class="panel-heading" style="background-color:#000; height:55px; color:white;text-align: center;font-weight:bold; font-size:16px;">All Crop List</div>
 <div class="panel-body">
     <table class="table table-bordered table-condensed table-striped table-responsive">
       <tr style="background-color:#00bcd5; color:white;" align="left">
          <td>Id</td>
          <td>Name</td>
          <td>Wheat quantity</td>
            <td>rice Quantity</td>
          <td>Maize Quantity</td>
          <td>Phone</td>
          <td>Email</td>
              <td>State</td>
          <td>Pincode</td>
          <td>Descrpition</td>
         
        
          
          <td colspan="2">Action</td>
          
       </tr>
       
       
  <?php
    while($row=mysqli_fetch_array($res))
	  {
   ?>
       <tr>
           <td><?php echo $row['id'];?></td>
           <td><?php echo $row['name'];?></td>
           <td><?php echo $row['wheat_quan'];?></td>
            <td><?php echo $row['rice_quan'];?></td>
           <td><?php echo $row['maize_quan'];?></td>
           <td><?php echo $row['phone'];?></td>
           <td><?php echo $row['email'];?></td>
           <td><?php echo $row['state'];?></td>
            <td><?php echo $row['pincode'];?></td>
           <td><?php echo $row['description'];?></td>
           
          
      
           
           <td><a class="btn btn-danger" href="deleteproduct.php?id=<?php echo $row['id']?>" style="padding:10px;"onClick="return confirm('Are you sure want to cancel?')"><span class="glyphicon glyphicon-trash"></span> Delete</a></td>
        
       </tr>
   <?php
	  }}
	   else
	   {
	    echo "<script>alert('you are not allowed to access this page');</script>";
	  }
	 ?>
	 </table>
    </div>
</div>
  <!-- map -->
    <div class="map mt-5">
      <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14236.3569440796!2d75.7631839!3d26.8689058!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x856b92e92b237be7!2sGD+Badaya+Memorial+Auditorium!5e0!3m2!1sen!2sin!4v1561272304040!5m2!1sen!2sin"
       allowfullscreen></iframe>
    </div>
    <!-- //map -->
  </div>
</section>
<!-- //contact -->



<?php include 'footer.php';
  ?>



