
            	<?php include 'header.php';
	?>
<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->
					 <?php 
 if(isset($_SESSION['fuser']))
 {

?>
<!-- contact -->
<section class="contact py-5">
	<div class="container py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center">Add Crop</h3>
		<div class="row map-pos">
			<div class="col-lg-4 col-md-6 address-row">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-home" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Visit Us</h5>
						<p>CityFarm, GD Badaya Auditorium.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 address-row w3-agileits">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-envelope" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Mail Us</h5>
						<p><a href="mailto:info@example.com">cityfarm@gmail.com</a></p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 address-row">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-phone" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Call Us</h5>
						<p>+91 9509824706</p>
					</div>
				</div>
			</div>
		</div>


















		<form action="#" method="post" enctype="multipart/form-data" name="farmerrate">
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="name" placeholder="Your Name" required="">
					<input type="email" name="email" placeholder="Email" required="">
					<input type="number" name="wheat_quan" placeholder="50Kg packs of wheat" required="">
					<input type="number" name="rice_quan" placeholder="50Kg packs of rice" required="">
					<input type="number" name="maize_quan" placeholder="50Kg packs of maize" required="">
					
					
					<input type="text" name="state" placeholder="State" required="">
					<input type="text" name="pincode" placeholder="Pincode" required="">
					<input type="text" name="phone" placeholder="Mobile Number" required="">



										

				</div>

				<div class="col-md-6 contact-right mt-md-0 mt-4">
										<textarea name="description" placeholder="Crop Description" required=""></textarea>
										<input type="file" name="pic" placeholde="choose image" class="form-control"  required>

										<button class="btn" name="add_product">Submit</button>
				</div>
				<?php

						 include('connect.php');
						 if(isset($_POST['add_product']))
						 {
							
					
							$name=$_REQUEST['name'];
							$wheat_quan=$_REQUEST['wheat_quan'];
							$rice_quan=$_REQUEST['rice_quan'];
							$maize_quan=$_REQUEST['maize_quan'];
							$description=$_REQUEST['description'];
							$state=$_REQUEST['state'] ;	
							$pincode=$_REQUEST['pincode'] ;
							$phone=$_REQUEST['phone'] ;
							$user=$_SESSION['fuser'];
							

					        $email=$_REQUEST['email'] ;  
							$filename=$_FILES["pic"]["name"];
							$tempname=$_FILES["pic"]["tmp_name"];
							$folder="images/".$filename;
							move_uploaded_file($tempname, $folder);

							if($name !="" && $description !=""  && $state!=""  && $phone!="" )
							{

							$sql="insert into `add_product`(`name`,`wheat_quan`,`rice_quan`,`maize_quan`,`description`,`pic`,`state`,`pincode`,`phone`,`email`,`user`)values('$name','$wheat_quan','$rice_quan','$maize_quan','$description','$folder','$state','$pincode','$phone','$email','$user')";
							$res=mysqli_query($con,$sql);
							if($res>=1)
							{
								
								echo '<script>alert("Successfilly added.....");</script>';
							}
							else
							{
								echo '<script>alert("oops! Error Occured , Try again after sometime...");</script></div>';
							}
						  }}
					   ?><?php 
							}else

							 {echo "<script>alert('Please Login as farmer First to access this page');</script>";
	    echo "<script>window.location.href ='login.php'</script>";
	    
	  }
							 ?>	
			</div>
		</form>
		<!-- map -->
		<div class="map mt-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14236.3569440796!2d75.7631839!3d26.8689058!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x856b92e92b237be7!2sGD+Badaya+Memorial+Auditorium!5e0!3m2!1sen!2sin!4v1561272304040!5m2!1sen!2sin"
			 allowfullscreen></iframe>
		</div>
		<!-- //map -->
	</div>
</section>
<!-- //contact -->



<?php include 'footer.php';
	?>















	