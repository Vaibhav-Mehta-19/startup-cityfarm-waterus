	<?php 

 include 'header.php';
	?>
	
<!-- banner -->
<div class="innerpage-banner" id="home">
	<div class="inner-page-layer">
	</div>
</div>
<!-- //banner -->
<!-- contact -->

					 <?php 
 if(isset($_SESSION['user']))
 {

?>
<section class="mail pt-lg-5 pt-4">
 
	<div class="container pt-lg-5">
		<h2 class="heading text-center mb-sm-5 mb-4">Upload Records </h2>
		<div class="row contact-form_grids">
			<div class="col-lg-8 contact-form_left">
				<form action="" method="post" name="myForm" enctype="multipart/form-data">
					<div class="row">
						<div class="col-md-6 form_contact_left_grid pr-md-0">
							<div class="form-group">
								<input type="text" name="patient" class="form-control" placeholder="Patient Name" required>
							</div>
							<div class="form-group">
								<input type="text" name="doctor" class="form-control" placeholder="Doctor Name" required>
							
							</div>
	<div class="form-group">
							<input type="date" name="date" class="form-control" placeholder="date of prescription" required>
							</div>
						</div>
						<div class="col-md-6 form_contact_left_grid">
							<div class="form-group">
								<select name="cat">
            
            <?php 
             include('connect.php');
             $que=mysqli_query($con,"select * from category");
            		while($cate=mysqli_fetch_array($que)){
            ?>
            	<option value="<?php if (isset($cate['id'])) echo $cate['category']; ?>"><?php echo $cate['category'];?></option>
            	<?php }?>
            </select>
							</div>
							<div class="form-group">
							<input type="file" name="pic" placeholde="choose image" class="form-control" required/><br>
							<input type="file" name="pic1" placeholde="choose image" class="form-control" required/><br>
							<input type="file" name="pic2" placeholde="choose image" class="form-control" required/><br>
								
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
									<textarea name="description" placeholder="Brief Description" class="form-control" required></textarea>
							</div>
						</div>
						<div class="col-md-12">
							<div class="submit-buttons">
								<button type="submit" value="submit" name="addpro" class="btn">Submit</button>
								<?php

						 include('connect.php');
						 if(isset($_POST['addpro']))
						 {
							
					
							$patient=$_REQUEST['patient'];
							$doctor=$_REQUEST['doctor'];
							$description=$_REQUEST['description'];
							$date=$_REQUEST['date'] ;
							$filename=$_FILES["pic"]["name"];
							$tempname=$_FILES["pic"]["tmp_name"];
							$folder="images/".$filename;
							move_uploaded_file($tempname, $folder);



							$filename1=$_FILES["pic1"]["name"];
							$tempname=$_FILES["pic1"]["tmp_name"];
							$folder1="images/".$filename1;
							move_uploaded_file($tempname, $folder1);


							$filename2=$_FILES["pic2"]["name"];
							$tempname=$_FILES["pic2"]["tmp_name"];
							$folder2="images/".$filename2;
							move_uploaded_file($tempname, $folder2);

							$cat=$_REQUEST['cat'];
							$user=$_SESSION['user'];
							
						if($patient !="" && $doctor  !="" && $description !="" && $cat!="" && $user!="" && $filename!="" && $tempname!="" &&$folder!="")
							{

							$sql="insert into `add_product` (`patient`,`doctor`,`description`,`pic`,`cat`,`user`,`date`,`pic1`,`pic2` )values('$patient','$doctor','$description','$folder','$cat','$user','$date','$folder1','$folder2')";
							$res=mysqli_query($con,$sql);
							if($res>=1)
							{
								
								echo '<script>alert("Successfilly added.....");</script>';
							}
							else
							{
								echo '<script>alert("oops! Error Occured , Try again after sometime...");</script></div>';
							}
						  }
						  else
						  {
						  		echo '<script>alert("login required");</script></div>';

						  }}
					   ?><?php 
							}else

							 {echo "<script>alert('Please Login First to access this page');</script>";
	    echo "<script>window.location.href ='login.php'</script>";
	    
	  }
							 ?>	
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="col-lg-4 col-md-6 mt-lg-0 mt-4 contact-info">
				<h4 class="mb-4">Address Information</h4>
				<p><span class="fa mr-2 fa-map-marker"></span>JK LAKSHMIPAT UNVIVERSITY, <span>JAIPUR</span></p>
				<p class="phone py-2"><span class="fa mr-2 fa-phone"></span>Phone : +91 9509824706 </p>
				<p><span class="fa mr-2 fa-envelope"></span>Email : <a href="mailto:info@example.com">medipository@jklu.edu.in</a></p>
				
				<h4 class="my-4">Book Your Appointment</h4>
				<p class="phone"><span class="fa mr-2 fa-phone"></span>Call us at +91 8005943630 </p>
			</div>
		</div>
	</div>
	
</section>
<!-- //contact -->

<?php include 'footer.php';
	?>