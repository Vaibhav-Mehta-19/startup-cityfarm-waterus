<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();
ob_start();
include('connect.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cityfarm best place for farmers to sell their crops at the best price and contct to consumer directly.</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<link href="css/css_slider.css" type="text/css" rel="stylesheet" media="all">

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Thasadith:400,400i,700,700i&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
	
</head>
<body>

<!-- header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-4 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-leaf"></span>  CityFarm</a></h1>
			</div>
			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu mt-md-2 ml-auto">
				<li class="mr-lg-4 mr-2 active"><a href="index.php">Home</a></li>
				<li class="mr-lg-4 mr-2"><a href="about.php">About Us</a></li>
				<li class="mr-lg-4 mr-2"><a href="contact.php">Contact</a></li>
				
								<li class="mr-lg-4 mr-2"><a href="comingsoon.php">Gallery</a></li>


				

					<?php 
         if(isset($_SESSION['user'])){
         	   ?>

<li class=""><a href="vm1.php">Buy Now &nbsp;&nbsp;</a></li>
         	   
<li class=""><a href="">Welcome,<?php echo "'".$_SESSION['user']."'";?></a></li>




<li class=""><a href="logout.php">&nbsp;&nbsp;logout</a>
	


        

           <?php 
}


else
{
	


?>






	<?php 
         if(isset($_SESSION['fuser'])){
         	   ?>


<li class=""><a href="add_product.php">Upload Crop ratelist &nbsp;&nbsp;</a></li>
<li class=""><a href="checkstatus.php">Check Status &nbsp;&nbsp;</a></li>
<li class=""><a href="">Welcome,<?php echo "'".$_SESSION['fuser']."'";?>&nbsp;&nbsp;</a></li>

<li class=""><a href="logout.php">logout</a>


           <?php 
}















         if(isset($_SESSION['admin'])){
         	   ?>


<li class=""><a href="adminview.php">Admin Dashboard &nbsp;&nbsp;</a></li>
<li class=""><a href="">Welcome,<?php echo "'".$_SESSION['admin']."'";?>&nbsp;&nbsp;</a></li>

<li class=""><a href="logout.php">logout</a>


           <?php 
}




















if(isset($_SESSION['admin'])== "" &&isset($_SESSION['fuser'])== "" &&isset($_SESSION['user'])== "")
{
	
?>

				
								<li class="mr-lg-4 mr-2"><a href="login.php">Login</a></li>

				<li class="mr-lg-4 mr-2"><a href="register.php">Register</a></li>
<?php 

} 

?>


			


<?php 

} 

?>		
			</ul>
		</nav>
		<!-- //nav -->
	</div>
</header>
<!-- //header -->