
<?php include 'header.php';
	?>
<!-- banner -->
<section class="banner_w3lspvt" id="home">
	<div class="csslider infinity" id="slider1">
		<!--<input type="radio" name="slides" checked="checked" id="slides_1" />
		<input type="radio" name="slides" id="slides_2" />
		<input type="radio" name="slides" id="slides_3" />
		<input type="radio" name="slides" id="slides_4" /> -->
		<ul>
			<li>
				<div class="banner-top">
					<div class="overlay">
						<div class="container">
							<div class="w3layouts-banner-info text-center">
								<h3 class="text-wh">CITYFARM</h3>
								<h4 class="text-wh mx-auto my-4">Connecting Farmers and Consumers</h4>
								<p class="text-li mx-auto mt-2">A direct connection between farmers and consumers so that farmer can directly sell their crops and can get better price and customers can get better farm products. </p>
								<a href="about.php" class="button-style mt-sm-5 mt-4">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="banner-top1">
					<div class="overlay1">
						<div class="container">
							<div class="w3layouts-banner-info text-center">
								<h3 class="text-wh">Farming</h3>
								<h4 class="text-wh mx-auto my-4">Cultivating new crops to make farmers increase profits</h4>
								<p class="text-li mx-auto mt-2">Ut enim ad minim quis nostrud exerci sed do eiusmod tempor incididunt ut
									labore et dolore magna aliqua nostrud exerci sed.</p>
								<a href="about.html" class="button-style mt-sm-5 mt-4">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="banner-top2">
					<div class="overlay">
						<div class="container">
							<div class="w3layouts-banner-info text-center">
								<h3 class="text-wh">Cultivating</h3>
								<h4 class="text-wh mx-auto my-4">Cultivating new crops to make farmers increase profits</h4>
								<p class="text-li mx-auto mt-2">Ut enim ad minim quis nostrud exerci sed do eiusmod tempor incididunt ut
									labore et dolore magna aliqua nostrud exerci sed.</p>
								<a href="about.html" class="button-style mt-sm-5 mt-4">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="banner-top3">
					<div class="overlay1">
						<div class="container">
							<div class="w3layouts-banner-info text-center">
								<h3 class="text-wh">Harvesting</h3>
								<h4 class="text-wh mx-auto my-4">Cultivating new crops to make farmers increase profits</h4>
								<p class="text-li mx-auto mt-2">Ut enim ad minim quis nostrud exerci sed do eiusmod tempor incididunt ut
									labore et dolore magna aliqua nostrud exerci sed.</p>
								<a href="about.html" class="button-style mt-sm-5 mt-4">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
		<div class="arrows">
			<label for="slides_1"></label>
			<label for="slides_2"></label>
			<label for="slides_3"></label>
			<label for="slides_4"></label>
		</div>
	</div>
</section>
<!-- //banner -->

<!-- about -->
<section class="about py-5">
	<div class="container py-md-4">
		<h3 class="heading text-center mb-4">Best Platform To Sell Yours Crops.</h3>
		<p class="about-text mx-auto text-center">We are here to make your life better.
        Upload your crops list and get the best price ever.</p>
		<div class="feature-grids row mt-5 text-center">
			<div class="col-lg-4 ">
				<div class="bottom-gd px-2 text-center">
					<div class="f-icon">
						<span class="fa fa-leaf" aria-hidden="true"></span>
					</div>
					<h3 class="mt-4"> Cereals</h3>
					<p class="mt-3">We are primarily selling three crops Wheat,Maize and Rice.</p>
				</div>
                
			</div>
            <div class="col-lg-4 ">
				<div class="bottom-gd px-2 text-center">
					<div class="f-icon">
						<span class="fa fa-leaf" aria-hidden="true"></span>
					</div>
					<h3 class="mt-4"> Fruits</h3>
					<p class="mt-3">We Are Also Working For Fruits Delivery.</p>
				</div>
                
			</div>
            <div class="col-lg-4 ">
				<div class="bottom-gd px-2 text-center">
					<div class="f-icon">
						<span class="fa fa-leaf" aria-hidden="true"></span>
					</div>
					<h3 class="mt-4"> Vegetables</h3>
					<p class="mt-3">We Are Also Working For Vegetables Delivery.</p>
				</div>
                
			</div>
		</div>
	</div>
</section>
<!-- //about -->

<!-- Why Choose Us -->
<section class="serives-agile py-5" id="works">
	<div class="container py-md-5">
		<h3 class="heading mb-5 text-center"> Why Choose Us</h3>
		<div class="welcome-bottom text-center">
			<div class="welcome-grid">
				<span class="fa fa-apple"></span>
				<h4 class="my-3">Quality </h4>
				<p>Get the best quality product.</p>
			</div>
			<div class="welcome-grid">
				<span class="fa fa-skyatlas"></span>
				<h4 class="my-3">On Time</h4>
				<p>Ensuring delievry on time.</p>
			</div>

			<div class="welcome-grid mt-md-0 mt-5">
				<span class="fa fa-yelp"></span>
				<h4 class="my-3">Safety</h4>
				<p>Get your product safely.</p>
			</div>
			<div class="welcome-grid mt-lg-0 mt-md-4 mt-5">
				<span class="fa fa-viadeo"></span>
				<h4 class="my-3">Variety</h4>
				<p>Choose among various varities.</p>
			</div>
			<div class="welcome-grid mt-lg-0 mt-md-4 mt-5">
				<span class="fa fa-pagelines"></span>
				<h4 class="my-3">Pricing</h4>
				<p>Get the best price ever.</p>
			</div> 
			<div class="clearfix"></div>
		</div>
	</div>
</section>
<!-- Why Choose Us -->

<!-- core values -->
<section class="core-value py-5">
	<div class="container py-md-4">
		<h3 class="heading mb-sm-5 mb-4 text-center"> Our Core Values</h3>
		<div class="row core-grids">
			<div class="col-lg-6 core-left">	
				<img src="images/core.jpg" class="img-fliud" alt="" />
			</div>
			<div class="col-lg-6 core-right">
				<h4 class="mt-4">Improving Agriculture, Improving Lives, Cultivating New Crops To Make Farmers Increase Profit.</h4>
				<p class="mt-3">
				We are here to provide the best price of crops. This will help both the farmers and consumers.Farmers will get the deserved price of their crops and consumers will also get the best cereals on the best price.</p>
			</div>
		</div>
	</div>
</section>
<!-- //core values -->
	
<!-- text -->
<section class="background-img">
	<div class="overlay-clr py-5">
		<div class="container py-md-3">
			<div class="row core-grids">
				<div class="col-lg-4 bg-left">	
					<h4 class="">We are working on the mission of "Jai Jawan Jai Kissan".So We Are Trying To Make The Livelihood Of Farmers Better.</h4>
				</div>
				<!--<div class="col-lg-5 col-md-7 bg-middle mt-lg-0 mt-4">	
					<p class="">Integer sit amet mattis quam, sit amet dol ultricies velit. Praesent ullam corper duits turpis dolor sit amet quam.
					Nulla comodol gravida porttitor. Aenean posuere lacusnt quis leo imperdiet laoreet. Proin vulputat.</p>
					<p class="mt-3">Integer sit ut amet mattis quam, sit amet ultricies velit. Praesent ullam corper dui turpis dolor sit amet quam.
					Nulla sed commodo gravida porttitor.</p>
				</div> !-->
				<div class="col-lg-3 col-md-5 bg-right mt-lg-0 mt-4">	
					<ul>
						<li><span class="fa fa-pagelines"></span> Connecting Farmers And Consumers</li>
						<li><span class="fa fa-pagelines"></span> Best Crop Pricing</li>
						<li><span class="fa fa-pagelines"></span> Pure Cereals</li>
						<!--<li><span class="fa fa-pagelines"></span> Improving Agriculture</li>
						<li><span class="fa fa-pagelines"></span> Innovators in Agricultural business</li>
						<li><span class="fa fa-pagelines"></span> Agricultural Robots</li>!-->
						<li><span class="fa fa-pagelines"></span> On Time Delivery</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //text -->

<!-- Products & Services -->
<section class="blog py-5">
	<div class="container py-md-5">
		<h3 class="heading mb-sm-5 mb-4 text-center"> Our Products and Services</h3>
		<div class="row blog-grids">
			<div class="col-lg-4 col-md-6 mb-lg-0 mb-sm-5 pb-lg-0 pb-5">	
				<img src="images/s1.jpg" class="img-fliud" alt="" />
				<div class="blog-info">
					<h4>Selling Crops <span class="fa fa-pagelines"></span></h4>
					<p class="mt-2">We are providing a platform to get the best cereals at best price.</p>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 mb-lg-0 mb-sm-5 pb-lg-0 pb-md-5">	
				<img src="images/s2.jpg" class="img-fliud" alt="" />
				<div class="blog-info">
					<h4>WaterUS<span class="fa fa-pagelines"></span></h4>
					<p class="mt-2">WaterUS Is Our another product for automated irrigation system, to help the farmers.</p>
				</div>
            
			</div>
		</div>
	</div>
</section>
<!-- //Products & Services -->

<!-- text -->
<section class="text py-5">
	<div class="container py-md-3 text-center">		
		<div class="row">
			<div class="col-12">
				<h3 class="mb-4 heading">This Is The Time To <span>Be Your Own Boss.</span></h3>
				<p>Stop requesting middlemens to sell your crops, Let be your own boos.Sell your crops here and get the deserved price.</p>
				<a href="contact.html" class="btn btn1"> Contact Us </a>
			</div>		
		</div>		
	</div>		
</section>
<!-- //text -->

<?php include 'footer.php';
	?>