<?php include 'header.php';
	?>

<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- Comingsoon -->
<section class="comingsoon py-5">
	<div class="container py-md-5">
		<div class="row">
			<div class="col-lg-6 offset-lg-6 col-md-8 offset-md-4">
				<h4>Under Construction</h4>
				<p class="mt-3">Our Gallery page is currently undergoing scheduled maintenance. We should be back shortly. Thank you for your patience.</p>
				<div class="mt-4">
					<form action="#" method="post" class="newsletter">
						<input class="email" type="email" name="email" placeholder="Enter your email id..." required="">
						<button class="form-control btn" name="newsletter" value="">Subscribe</button>
					</form>
				</div>
				<p class="mt-2">Sign up now to get early notification!</p>
			</div>
		</div>
	</div>
</section>
<!-- //Comingsoon -->




<?php 
include('connect.php');

if(isset($_POST['newsletter'])){

$email=$_REQUEST['email'];

	


$sql="insert into newsletter(`email`) values('$email')";

$res=mysqli_query($con,$sql);
if($res>=1){

echo "<script>alert('Sucessfully Subscribed!! Hope you will enjoy');</script>";


}
else{

echo "<script>alert('oops! Error Occur. Please try again later');</script>";

}

}
?>

<?php include 'footer.php';
	?>