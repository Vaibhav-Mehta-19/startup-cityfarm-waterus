	<?php include 'header.php';
	?>

<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="Agro Harvest Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<link href="css/css_slider.css" type="text/css" rel="stylesheet" media="all">

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Thasadith:400,400i,700,700i&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
	
</head>
<body>
<!-- //header -->
<header>
	<div class="container">
		<!-- nav -->
		<nav class="py-4 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-leaf"></span> CityFarm</a></h1>
			</div>
			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu mt-md-2 ml-auto">
				<li class="mr-lg-4 mr-2"><a href="index.html">Home</a></li>
				<li class="mr-lg-4 mr-2"><a href="about.html">About Us</a></li>
				<li class="mr-lg-4 mr-2"><a href="services.html">Services</a></li>
				<li class="mr-lg-4 mr-2"><a href="comingsoon.html">Gallery</a></li>
				<li class="mr-lg-4 mr-2"><a href="contact.html">Contact</a></li>
								<li class="mr-lg-4 mr-2"><a href="login.html">Login</a></li>

				<li class="mr-lg-4 mr-2"><a href="register.html">Register</a></li>

				<li class="mr-lg-4 mr-2"><span><span class="fa fa-phone"></span> +91 9509824706</span></li>
			</ul>
		</nav>
		<!-- //nav -->
	</div>
</header>
<!-- //header -->

<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- contact -->
<section class="contact py-5">
	<div class="container py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center"> Farmer Register</h3>
		<div class="row map-pos">
			
			
			
		</div>
		<form action="#" method="post">
			<div class="row">
				<div class="col-md-6 contact-left">
					<input type="text" name="name" placeholder="Your Name" required="">
					<input type="email" name="email" placeholder="Email" required="">
					<input type="Password" name="password" placeholder="Password" required="">

					<input type="text" name="state" placeholder="State" required="">
					<input type="text" name="pincode" placeholder="Pincode" required="">
					<input type="text" name="phone" placeholder="Mobile Number" required="">
				</div>

				<div class="col-md-6 contact-right mt-md-0 mt-4">
					
					<button class="btn" name="register">Submit</button>
				</div>
			</div>
		</form>
		<!-- map -->
		<div class="map mt-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14236.3569440796!2d75.7631839!3d26.8689058!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x856b92e92b237be7!2sGD+Badaya+Memorial+Auditorium!5e0!3m2!1sen!2sin!4v1561272304040!5m2!1sen!2sin"
			 allowfullscreen></iframe>
		</div>
		<!-- //map -->
	</div>
</section>
<!-- //contact -->
<?php include 'footer.php';
	?>




<?php 
include('connect.php');

if(isset($_POST['register'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$state=$_REQUEST['state'];

$pincode=$_REQUEST['pincode'];
$password=md5($_REQUEST['password']);



$sql="insert into fregister(`name`,`email`,`phone`,`state`,`pincode`,`password`) values('$name','$email','$phone','$state','$pincode','$password')";

$res=mysqli_query($con,$sql);
if($res>=1){




echo "<script>alert('registered');</script>";


}
else{

echo "<script>alert('not registered');</script>";

}

}
?>

<!-- //contact -->

<?php include 'footer.php';
	?>