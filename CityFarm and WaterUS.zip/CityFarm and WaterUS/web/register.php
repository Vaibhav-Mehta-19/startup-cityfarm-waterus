	<?php include 'header.php';
	?>
<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- contact -->
<section class="contact py-5">
	<div class="container py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center">Register</h3>
		<div class="row map-pos">
			<div class="col-lg-4 col-md-6 address-row">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-home" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Visit Us</h5>
						<p>CityFarm, GD Badaya Auditorium.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 address-row w3-agileits">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-envelope" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Mail Us</h5>
						<p><a href="mailto:info@example.com">cityfarm@gmail.com</a></p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 address-row">
				<div class="row">
					<div class="col-2 address-left">
						<div class="contact-icon">
							<span class="fa fa-phone" aria-hidden="true"></span>
						</div>
					</div>
					<div class="col-10 address-right">
						<h5>Call Us</h5>
						<p>+91 9509824706</p>
					</div>
				</div>
			</div>
		</div>
		<form action="#" method="post">
			<div class="row">
				<div class="col-md-6 contact-left">
					<input type="text" name="name" placeholder="Your Name" required="">
					<input type="email" name="email" placeholder="Email" required="">
					<input style="    
    width: 540px;
    height: 56px;" type="Password" name="password" placeholder="Password" required="">

					<input style="    margin: 24px 0px;
    padding: 15px 20px;" type="text" name="state" placeholder="State" required="">
					<input type="text" name="pincode" placeholder="Pincode" required="">
					<input  style="    margin: 24px 0px;
    padding: 15px 20px;"type="text" name="phone" placeholder="Mobile Number" required="">
				</div>

				<div class="col-md-6 contact-right mt-md-0 mt-4">
					
					<button class="btn" name="register">Register as Consumer</button>
						<button class="btn" name="fregister">Register as Farmer</button>
				</div>
			</div>
		</form>
		<!-- map -->
		<div class="map mt-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14236.3569440796!2d75.7631839!3d26.8689058!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x856b92e92b237be7!2sGD+Badaya+Memorial+Auditorium!5e0!3m2!1sen!2sin!4v1561272304040!5m2!1sen!2sin"
			 allowfullscreen></iframe>
		</div>
		<!-- //map -->
	</div>
</section>
<!-- //contact -->



<?php include 'footer.php';
	?>

















<?php 
include('connect.php');

if(isset($_POST['register'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$state=$_REQUEST['state'];

$pincode=$_REQUEST['pincode'];
$password=md5($_REQUEST['password']);



$sql="insert into register(`name`,`email`,`phone`,`state`,`pincode`,`password`) values('$name','$email','$phone','$state','$pincode','$password')";

$res=mysqli_query($con,$sql);
if($res>=1){




echo "<script>alert('registered');</script>";


}
else{

echo "<script>alert('not registered');</script>";

}

}
?>









<?php 
include('connect.php');

if(isset($_POST['fregister'])){
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$state=$_REQUEST['state'];

$pincode=$_REQUEST['pincode'];
$password=md5($_REQUEST['password']);



$sql="insert into fregister(`name`,`email`,`phone`,`state`,`pincode`,`password`) values('$name','$email','$phone','$state','$pincode','$password')";

$res=mysqli_query($con,$sql);
if($res>=1){




echo "<script>alert('registered');</script>";


}
else{

echo "<script>alert('not registered');</script>";

}

}
?>

<!-- //contact -->

	