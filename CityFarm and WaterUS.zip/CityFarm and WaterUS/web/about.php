<?php include 'header.php';
	?>

<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- about -->
<section class="about py-5" id="about">
	<div class="container py-lg-5 py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center"> About CITYFARM</h3>
		<div class="row">
			<div class="col-lg-6 about-left">
				<h5 class="mb-3">Few Words About Us!</h5>
				<h3 class="mb-lg-4 mb-2">We are connecting farmers and consumers</h3>
				<h4 class=""> Our goal is to reduce the farmer suicide rate in India</h4>
			</div>
			<div class="col-lg-6 pl-xl-5 mt-lg-0 mt-4 about-right">
				<p>CITYFARM app is basically a direct connection between farmers and cosumers.Here farmers can upload available crops with the price and then consumers can directly buy the crops from the farmers in the best price.</p>
				<!--<p class="pt-3 mt-3 border-top"><span class="fa fa-quote-left text-color mr-2"></span>Nullam consequat sapien ut
					leot cursus rhoncus. Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla sed accumsan ac elit in congue. Class aptent taciti sociosqu ad
					litora torquent per taciti sociosqu ad litora torquent.</p>!-->
			</div>
		</div>
	</div>
</section>
<!-- //about -->

<!-- about bottom -->
<div class="abt_bottom py-md-5">
	<div class="container py-md-4 py-5">
		<div class="row">
			<div class="col-md-9">
				<h4 class="abt-text text-capitalize">We give you Care tips and Ideas on what style suits your garden</h4>
			</div>
		</div>
	</div>
</div>
<!-- //about bottom -->

<!-- stats -->
<!--<section class="w3_stats" id="stats">
	<div class="overlay-clr py-sm-5">
		<div class="container py-5">
			<div class="w3-stats">
				<div class="row">
					<div class="col-lg-3 col-6">
						<div class="counter">
							<span class="fa fa-smile-o"></span>
							<div class="timer count-title count-number mt-2">5100</div>
							<p class="count-text text-uppercase">happy customers</p>
						</div>
					</div>
					<div class="col-lg-3 col-6">
						<div class="counter">
							<span class="fa fa-pagelines"></span>
							<div class="timer count-title count-number mt-2">2271</div>
							<p class="count-text text-uppercase">Planted Trees</p>
						</div>
					</div>
					<div class="col-lg-3 col-6 mt-lg-0 mt-5">
						<div class="counter">
							<span class="fa fa-users"></span>
							<div class="timer count-title count-number mt-2">1120+</div>
							<p class="count-text text-uppercase">Farmers</p>
						</div>
					</div>
					<div class="col-lg-3 col-6 mt-lg-0 mt-5">
						<div class="counter">
							<span class="fa fa-leaf"></span>
							<div class="timer count-title count-number mt-2">2690</div>
							<p class="count-text text-uppercase">Products</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-->
<!-- //stats -->

<!-- team --
<div class="team py-5" id="team">
	<div class="container py-lg-3">
		<h3 class="heading mb-sm-5 mb-4 text-center"> Our Team</h3>
		<div class="row team-bottom text-center">
			<div class="col-lg-3 col-sm-6 team-grid">
				<img src="images/team1.jpg" class="img-fluid" alt="">
				<div class="caption">
					<div class="team-text">
						<h4>Mack Joe</h4>
					</div>
					<ul class="mt-2">
						<li>
							<a href="#">
								<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="mailto:info@example.com">
								<span class="fa fa-envelope-open" aria-hidden="true"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 team-grid mt-sm-0 mt-5">
				<img src="images/team2.jpg" class="img-fluid" alt="">
				<div class="caption">
					<div class="team-text">
						<h4>Cruz Deo</h4>
					</div>
					<ul class="mt-2">
						<li>
							<a href="#">
								<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="mailto:info@example.com">
								<span class="fa fa-envelope-open" aria-hidden="true"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 team-grid mt-lg-0 mt-5">
				<img src="images/team3.jpg" class="img-fluid" alt="">
				<div class="caption">
					<div class="team-text">
						<h4>Rochy Jae</h4>
					</div>
					<ul class="mt-2">
						<li>
							<a href="#">
								<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="mailto:info@example.com">
								<span class="fa fa-envelope-open" aria-hidden="true"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 team-grid  mt-lg-0 mt-5">
				<img src="images/team4.jpg" class="img-fluid" alt="">
				<div class="caption">
					<div class="team-text">
						<h4>Rojo Poy</h4>
					</div>
					<ul class="mt-2">
						<li>
							<a href="#">
								<span class="fa fa-facebook" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus" aria-hidden="true"></span>
							</a>
						</li>
						<li>
							<a href="mailto:info@example.com">
								<span class="fa fa-envelope-open" aria-hidden="true"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
//team -->

<!-- feedback --
<section class="news py-5">
	<div class="container py-xl-5 py-lg-3">
		<h3 class="heading mb-sm-5 mb-4 text-center">Clients Testimonials</h3>
		<div class="row">
			<div class="col-lg-4 item">
				<div class="feedback-info pt-5 pb-4 px-4">
					<h4 class="mb-3">Best Harvesting Company
					</h4>
					<p><span class="fa fa-quote-left text-color mr-2"></span> Vulputate ac met semper varius Nullam consequat sapien sed leot cursus rhoncus. Nullam dui mi.</p>
					<div class="feedback-grids mt-3">
						<div class="feedback-img">
							<img src="images/te1.jpg" class="img-fluid rounded-circle" alt="" />
						</div>
						<div class="feedback-img-info">
							<h5>Mary Jane</h5>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 item-2 mt-lg-0 mt-4">
				<div class="feedback-info pt-5 pb-4 px-4">
					<h4 class="mb-3">Best Agricultural farm
					</h4>
					<p><span class="fa fa-quote-left text-color mr-2"></span> Vulputate ac met semper varius Nullam consequat sapien sed leot cursus rhoncus. Nullam dui mi.</p>
					<div class="feedback-grids mt-3">
						<div class="feedback-img">
							<img src="images/te2.jpg" class="img-fluid rounded-circle" alt="" />
						</div>
						<div class="feedback-img-info">
							<h5>Olivia Ruth</h5>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 item mt-lg-0 mt-4">
				<div class="feedback-info pt-5 pb-4 px-4">
					<h4 class="mb-3">Modern Cultivation
					</h4>
					<p><span class="fa fa-quote-left text-color mr-2"></span> Vulputate ac met semper varius Nullam consequat sapien sed leot cursus rhoncus. Nullam dui mi.</p>
					<div class="feedback-grids mt-3">
						<div class="feedback-img">
							<img src="images/te3.jpg" class="img-fluid rounded-circle" alt="" />
						</div>
						<div class="feedback-img-info">
							<h5>Blake Joe</h5>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
 //feedback -->
<?php include 'footer.php';
	?>