<?php include 'header.php';
	?>

<!-- banner -->
<div class="inner-banner" id="home">
	<div class="container">
	</div>
</div>
<!-- //banner -->

<!-- contact -->
<section class="contact py-5">
	<div class="container py-sm-3">
		<h3 class="heading mb-sm-5 mb-4 text-center">Login</h3>
		<div class="row map-pos">
			
			
			
		</div>
		<form action="#" method="post">
			<div class="row">
				<div class="col-md-6 contact-left">
					
					<input type="email" name="email" placeholder="Email" required="">
					<input style="    
    width: 540px;
    height: 56px;"type="password" name="password" placeholder="password" required="">
				</div>
				<div class="col-md-6 contact-right mt-md-0 mt-4">
					
					<button name="login"class="btn">Login as Consumer</button>
					<button name="flogin"class="btn">Login as Farmer</button>
					<button name="adminlogin"class="btn">Login as Admin</button>
				</div>
			</div>
		</form>
		<!-- map -->
		<div class="map mt-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14236.3569440796!2d75.7631839!3d26.8689058!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x856b92e92b237be7!2sGD+Badaya+Memorial+Auditorium!5e0!3m2!1sen!2sin!4v1561272304040!5m2!1sen!2sin"
			 allowfullscreen></iframe>
		</div>
		<!-- //map -->
	</div>
</section>
<!-- //contact -->



<?php include 'footer.php';
	?>


    <?php 

    include('connect.php');
if(isset($_POST['login'])){
$email=$_REQUEST['email'];
$password=md5($_REQUEST['password']);



$sql="select * from register where email='".$email."' and
password='".$password."'";


$res=mysqli_query($con,$sql);
$data=mysqli_fetch_array($res);



if($data){
$_SESSION['user']=$email;                       
#session for the consumer
#user


echo "<script>alert('login successfull');</script>";
echo "<script>window.location.href='index.php'</script>";



}
else{
echo "<script>alert(' Login failed email or password incorrect');</script>";

}

}


?>




    <?php 

    include('connect.php');
if(isset($_POST['flogin'])){
$email=$_REQUEST['email'];
$password=md5($_REQUEST['password']);



$sql="select * from fregister where email='".$email."' and
password='".$password."'";


$res=mysqli_query($con,$sql);
$data=mysqli_fetch_array($res);



if($data){
$_SESSION['fuser']=$email;

#session for farmer 
#fuser


echo "<script>alert('login successfull');</script>";
echo "<script>window.location.href='index.php'</script>";



}
else{
echo "<script>alert(' Login failed email or password incorrect');</script>";

}

}


?>



   <?php 

    include('connect.php');
if(isset($_POST['adminlogin'])){
$email=$_REQUEST['email'];
$password=($_REQUEST['password']);



$sql="select * from adminlogin where email='".$email."' and
password='".$password."'";


$res=mysqli_query($con,$sql);
$data=mysqli_fetch_array($res);



if($data){
$_SESSION['admin']=$email;

#session for farmer 
#fuser


echo "<script>alert('login successfull');</script>";
echo "<script>window.location.href='index.php'</script>";



}
else{
echo "<script>alert(' Login failed email or password incorrect');</script>";

}

}


?>

