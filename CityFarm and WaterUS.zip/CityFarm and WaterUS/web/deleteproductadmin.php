<?php

include('connect.php');
$id=$_REQUEST['id'];
$query = "DELETE FROM add_product WHERE id=$id"; 
$result = mysqli_query($con,$query) or die (mysqli_error());
header('location:adminview.php');
?>
